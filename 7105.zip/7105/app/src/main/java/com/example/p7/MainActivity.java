package com.example.p7;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText enroll,name,email;
    Button add,view,delete,update;

    SQLLite sQlLite;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {

            enroll = findViewById(R.id.enroll);
            name = findViewById(R.id.name);
            email = findViewById(R.id.email);
            add = findViewById(R.id.insert);
            view = findViewById(R.id.view);
            delete = findViewById(R.id.delete);
            update = findViewById(R.id.update);

            sQlLite = new SQLLite(this);

            add.setOnClickListener(v1 -> {
                String enroll;
            });

            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}